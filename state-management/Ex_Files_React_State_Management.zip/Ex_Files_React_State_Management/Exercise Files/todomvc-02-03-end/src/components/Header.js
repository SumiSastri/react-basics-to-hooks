import React from 'react'

const Header = () => (
  <header className="header">
    <h1>Books</h1>
  </header>
)


export default Header
