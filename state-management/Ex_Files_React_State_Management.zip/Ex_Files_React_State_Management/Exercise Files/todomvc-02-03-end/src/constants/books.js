export default [
    {
        id: 1,
        volumeInfo: {
            authors: ['Charles Dickens'],
            title: 'A Tale of Two Cities'
        },
        completed: false,
    },
    {
        id: 2,
        volumeInfo: {
            authors: ['Leo Tolstoy'],
            title: 'War and Peace'
        },
        completed: false,
    },
    {
        id: 3,
        volumeInfo: {
            authors: ['Mary Shelley'],
            title: 'Frankenstein'
        },
        completed: false,
    }
]