items: [
    {
        title: 'Pride and Prejudice',
        author: 'Jane Austen',
        image: 'http://books.google.com/books/context?id=Yvg',
        language: 'en'
    }
]