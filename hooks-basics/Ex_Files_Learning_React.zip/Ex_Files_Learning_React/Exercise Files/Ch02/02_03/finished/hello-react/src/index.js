import React from "react";
import ReactDOM from "react-dom";
import "./index.css";

ReactDOM.render(
  <ul>
    <li>Hot Dogs</li>
    <li>Hamburgers</li>
    <li>Pizza</li>
    <li>Sushi</li>
  </ul>,
  document.getElementById("root")
);
